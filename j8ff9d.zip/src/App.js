import React from "react";
import "./styles.css";
import SearchBar from "./components/Searchbar";

export default function App() {
  return (
    <div className="App">
      <SearchBar placeholder="Enter a book Name..." />
    </div>
  );
}

import React, { useState } from "react";
import "./SearchBar.css";
import SearchIcon from "@material-ui/icons/Search";
function SearchBar({ placeholder, data }) {
  const [filteredData, setfilteredData] = useState([]);
  const [wordEntered, setWordEntered] = useState([]);
  const handleFilter = (event) => {
    const searchword = event.target.value;
    setWordEntered(searchword);
    const newFilter = data.filter((value) => {
      return value.name.toLowercase().includes(searchword.toLowercase());
    });
    setFilteredData(newFilter);
  };
  const clearInput = () => {
    setFilteredData([]);
    setWordEntered("");
  };
  return (
    <div className="search">
      <div className="searchInputs">
        <input
          type="text"
          value={wordEntered}
          placeholder={placeholder}
          onChange={handleFilter}
        />
        <div className="searchIcon">
          {filteredData.length === 0 ? (
            <SearchIcon />
          ) : (
            <CloseIcon id="clearBtn" />
          )}
        </div>
      </div>
      {filteredData.length !== 0 && (
        <div className="dataResult">
          {filteredData.slice(0, 15).map((value, key) => {
            return <p className="dataItem">{value.name}</p>;
          })}
        </div>
      )}
    </div>
  );
}
export default SearchBar;
